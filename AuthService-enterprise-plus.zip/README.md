# AuthService (.NET 9, Vertical Slice, CQRS + MediatR, Dual DB, Identity, JWT, 2FA, External Auth, Aspire)

## Quick Start
1. Install .NET 9 SDK (Preview) and Docker.
2. Open the solution in VS 2022 Preview or run:
   ```bash
   dotnet restore
   dotnet build
   ```
3. Run with .NET Aspire:
   ```bash
   dotnet run --project src/AuthService.AppHost
   ```
4. API runs at http://localhost:8000 (depending on Aspire port mapping). Swagger is enabled in Development.

### Credentials
- Seeded Admin: `admin@example.com` / `Admin@12345`

### Notes
- Commands use SQL Server (`CommandDbContext`), Queries use PostgreSQL (`QueryDbContext`).
- Repository pattern used (`GenericRepository<T>`). No Unit of Work.
- Health checks: `/health`
- External auth config is in `appsettings.json` with test credentials.


## Added in this package
- **Outbox + Background Projection**: `OutboxMessage` (SQL Server) and `OutboxWorker` (API) which projects `UserCreated` events into the Postgres read model.
- **Email sender** via `IHttpClientFactory` (`HttpEmailSender`), endpoint configurable via `Email:Endpoint`.
- **Dockerfile** for API and **K8s** deployment/service manifests.


## External Authentication (Production-Grade)
- Implements OIDC discovery + signature validation for **Google** and **Microsoft** via `ExternalIdTokenValidator`.
- Configure client IDs in `appsettings.json` under `ExternalAuth`.
