namespace AuthService.Application.Abstractions;

public interface IEmailSender
{
    Task SendEmailConfirmationAsync(string toEmail, string token, CancellationToken ct = default);
    Task SendPasswordResetAsync(string toEmail, string token, CancellationToken ct = default);
}
