using AuthService.Domain.Users;

namespace AuthService.Application.Abstractions;

public interface ITokenService
{
    (string accessToken, DateTime expires) CreateAccessToken(AppUser user, IEnumerable<string> roles);
    Task<string> CreateAndStoreRefreshTokenAsync(AppUser user, TimeSpan? lifetime = null, CancellationToken ct = default);
    Task<bool> RevokeRefreshTokenAsync(string token, CancellationToken ct = default);
    Task<bool> ValidateRefreshTokenAsync(Guid userId, string token, CancellationToken ct = default);
}
