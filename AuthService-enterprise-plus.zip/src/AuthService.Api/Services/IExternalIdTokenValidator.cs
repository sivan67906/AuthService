using System.Security.Claims;

namespace AuthService.Api.Services;

public interface IExternalIdTokenValidator
{
    Task<(bool ok, ClaimsPrincipal? principal, string? error)> ValidateAsync(string provider, string idToken, CancellationToken ct = default);
}
