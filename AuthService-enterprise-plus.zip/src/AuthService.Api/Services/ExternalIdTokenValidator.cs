using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;

namespace AuthService.Api.Services;

public sealed class ExternalIdTokenValidator : IExternalIdTokenValidator
{
    private readonly IConfiguration _cfg;
    private readonly IMemoryCache _cache;

    public ExternalIdTokenValidator(IConfiguration cfg, IMemoryCache cache)
    { _cfg = cfg; _cache = cache; }

    public async Task<(bool ok, ClaimsPrincipal? principal, string? error)> ValidateAsync(string provider, string idToken, CancellationToken ct = default)
    {
        try
        {
            var (issuer, audience, metadata) = provider.ToLowerInvariant() switch
            {
                "google" => ("https://accounts.google.com", _cfg["ExternalAuth:Google:ClientId"]!, "https://accounts.google.com/.well-known/openid-configuration"),
                "microsoft" or "microsoftaccount" => ("https://login.microsoftonline.com/common/v2.0", _cfg["ExternalAuth:Microsoft:ClientId"]!, "https://login.microsoftonline.com/common/v2.0/.well-known/openid-configuration"),
                _ => throw new InvalidOperationException("Unsupported provider")
            };

            var cm = _cache.GetOrCreate($"oidc:{issuer}", entry =>
            {
                entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(12);
                var configManager = new ConfigurationManager<OpenIdConnectConfiguration>(metadata, new OpenIdConnectConfigurationRetriever());
                return configManager;
            }) as IConfigurationManager<OpenIdConnectConfiguration>;

            var cfg = await cm!.GetConfigurationAsync(ct);
            var tvp = new TokenValidationParameters
            {
                ValidIssuer = issuer,
                ValidAudiences = new[] { audience },
                IssuerSigningKeys = cfg.SigningKeys,
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidateLifetime = true,
                ValidateIssuerSigningKey = true,
                ClockSkew = TimeSpan.FromMinutes(2)
            };

            var handler = new JwtSecurityTokenHandler();
            var principal = handler.ValidateToken(idToken, tvp, out var _);
            return (true, principal, null);
        }
        catch (Exception ex)
        {
            return (false, null, ex.Message);
        }
    }
}
