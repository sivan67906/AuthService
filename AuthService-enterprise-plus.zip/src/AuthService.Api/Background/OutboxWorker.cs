using System.Text.Json;
using AuthService.Infrastructure.Commands;
using AuthService.Infrastructure.Commands.Outbox;
using AuthService.Infrastructure.Queries;
using Microsoft.EntityFrameworkCore;

namespace AuthService.Api.Background;

public sealed class OutboxWorker : BackgroundService
{
    private readonly ILogger<OutboxWorker> _logger;
    private readonly IServiceScopeFactory _scopeFactory;
    public OutboxWorker(ILogger<OutboxWorker> logger, IServiceScopeFactory scopeFactory)
    {
        _logger = logger; _scopeFactory = scopeFactory;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("OutboxWorker started.");
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope = _scopeFactory.CreateScope();
                var cmd = scope.ServiceProvider.GetRequiredService<CommandDbContext>();
                var qry = scope.ServiceProvider.GetRequiredService<QueryDbContext>();

                var items = await cmd.Outbox.Where(x => x.ProcessedUtc == null)
                    .OrderBy(x => x.CreatedUtc).Take(50).ToListAsync(stoppingToken);

                foreach (var msg in items)
                {
                    try
                    {
                        switch (msg.Type)
                        {
                            case "UserCreated":
                                var u = JsonSerializer.Deserialize<UserCreated>(msg.Payload)!;
                                var existing = await qry.Users.FirstOrDefaultAsync(x => x.Id == u.Id, stoppingToken);
                                if (existing is null)
                                {
                                    qry.Users.Add(new UserReadModel
                                    {
                                        Id = u.Id,
                                        Email = u.Email,
                                        FirstName = u.FirstName,
                                        LastName = u.LastName,
                                        Roles = u.Roles
                                    });
                                }
                                else
                                {
                                    existing.Email = u.Email;
                                    existing.FirstName = u.FirstName;
                                    existing.LastName = u.LastName;
                                    existing.Roles = u.Roles;
                                }
                                await qry.SaveChangesAsync(stoppingToken);
                                break;
                            default:
                                _logger.LogWarning("Unknown outbox type {Type}", msg.Type);
                                break;
                        }
                        msg.ProcessedUtc = DateTime.UtcNow;
                    }
                    catch (Exception ex)
                    {
                        msg.Error = ex.Message;
                        _logger.LogError(ex, "Error processing outbox message {Id}", msg.Id);
                    }
                }

                if (items.Count > 0)
                    await cmd.SaveChangesAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Outbox loop failure");
            }

            await Task.Delay(TimeSpan.FromSeconds(2), stoppingToken);
        }
    }

    private sealed record UserCreated(Guid Id, string Email, string? FirstName, string? LastName, string[] Roles);
}
