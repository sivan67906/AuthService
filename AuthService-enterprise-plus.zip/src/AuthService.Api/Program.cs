using System.Text;
using AuthService.Domain.Users;
using AuthService.Infrastructure.Commands;
using AuthService.Infrastructure.Commands.Seed;
using AuthService.Infrastructure.Commands.Services;
using AuthService.Application.Abstractions;
using AuthService.Infrastructure.Queries;
using AuthService.ServiceDefaults;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using FluentValidation;
using AuthService.Application.Abstractions;
using AuthService.Application.Users;
using Mapster;
using MapsterMapper;
using Microsoft.OpenApi.Models;
using AuthService.Api.Background;

var builder = WebApplication.CreateBuilder(args).AddServiceDefaults();

builder.Services.AddControllers();
builder.Services.AddMemoryCache();
builder.Services.AddHttpContextAccessor();

// DbContexts
builder.Services.AddDbContext<CommandDbContext>(opt =>
    opt.UseSqlServer(builder.Configuration.GetConnectionString("SqlServer")));

builder.Services.AddDbContext<QueryDbContext>(opt =>
    opt.UseNpgsql(builder.Configuration.GetConnectionString("Postgres")));

// Identity
builder.Services.AddIdentity<AppUser, AppRole>(options =>
{
    options.SignIn.RequireConfirmedEmail = true;
    options.Tokens.AuthenticatorTokenProvider = TokenOptions.DefaultAuthenticatorProvider;
}).AddEntityFrameworkStores<CommandDbContext>()
  .AddDefaultTokenProviders();

// MediatR + FluentValidation + Mapster
builder.Services.AddMediatR(typeof(Program));
builder.Services.AddValidatorsFromAssemblyContaining<RegisterRequestValidator>();
builder.Services.AddScoped<TypeAdapterConfig>(_ => new TypeAdapterConfig());
builder.Services.AddScoped<IMapper, ServiceMapper>();

// JWT
var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]!));
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(o =>
{
    o.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = key
    };
})
.AddGoogle("Google", opt => {
    opt.ClientId = builder.Configuration["ExternalAuth:Google:ClientId"]!;
    opt.ClientSecret = builder.Configuration["ExternalAuth:Google:ClientSecret"]!;
})
.AddMicrosoftAccount("Microsoft", opt => {
    opt.ClientId = builder.Configuration["ExternalAuth:Microsoft:ClientId"]!;
    opt.ClientSecret = builder.Configuration["ExternalAuth:Microsoft:ClientSecret"]!;
});

builder.Services.AddAuthorization();

// HttpClientFactory
builder.Services.AddHttpClient("email");

// Services
builder.Services.AddScoped<ITokenService, JwtTokenService>();
builder.Services.AddScoped<IEmailSender, HttpEmailSender>();
builder.Services.AddScoped<AuthService.Api.Services.IExternalIdTokenValidator, AuthService.Api.Services.ExternalIdTokenValidator>();

// Health checks
builder.Services.AddHealthChecks()
    .AddSqlServer(builder.Configuration.GetConnectionString("SqlServer")!)
    .AddNpgSql(builder.Configuration.GetConnectionString("Postgres")!);

// Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "AuthService API", Version = "v1" });
});

builder.Services.AddHostedService<OutboxWorker>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseSerilogRequestLogging();

app.UseAuthentication();
app.UseAuthorization();

app.MapDefaultEndpoints();

app.MapControllers();

// Seed command DB (roles/admin)
await CommandDbSeeder.SeedAsync(app.Services, app.Logger);

app.Run();
