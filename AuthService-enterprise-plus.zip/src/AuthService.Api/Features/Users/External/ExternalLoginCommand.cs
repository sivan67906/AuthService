using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using AuthService.Application.Abstractions;
using AuthService.Contracts.Users;
using AuthService.Domain.Users;
using MediatR;
using AuthService.Api.Services;
using Microsoft.AspNetCore.Identity;

namespace AuthService.Api.Features.Users.External;

public sealed record ExternalLoginCommand(ExternalLoginRequest Request) : IRequest<IResult>;

public sealed class ExternalLoginHandler : IRequestHandler<ExternalLoginCommand, IResult>
{
    private readonly UserManager<AppUser> _userManager;
    private readonly ITokenService _tokenService;
    private readonly IExternalIdTokenValidator _validator;

    public ExternalLoginHandler(UserManager<AppUser> userManager, ITokenService tokenService, IExternalIdTokenValidator validator)
    { _userManager = userManager; _tokenService = tokenService; _validator = validator; }

    public async Task<IResult> Handle(ExternalLoginCommand command, CancellationToken ct)
    {
        var (ok, principal, error) = await _validator.ValidateAsync(command.Request.Provider, command.Request.IdToken, ct);
        if (!ok || principal is null) return Results.BadRequest(error ?? "Invalid id token");
        var email = principal.FindFirst(ClaimTypes.Email)?.Value ?? principal.FindFirst("email")?.Value;
        if (string.IsNullOrEmpty(email)) return Results.BadRequest("Email claim missing.");

        var user = await _userManager.FindByEmailAsync(email);
        if (user is null)
        {
            user = new AppUser { UserName = email, Email = email, EmailConfirmed = true };
            var createRes = await _userManager.CreateAsync(user);
            if (!createRes.Succeeded) return Results.BadRequest(createRes.Errors.Select(e => e.Description));
            await _userManager.AddToRoleAsync(user, "User");
        }

        var roles = await _userManager.GetRolesAsync(user);
        var (access, exp) = _tokenService.CreateAccessToken(user, roles);
        var refresh = await _tokenService.CreateAndStoreRefreshTokenAsync(user);
        return Results.Ok(new TokenResponse(access, refresh, exp));
    }
}
