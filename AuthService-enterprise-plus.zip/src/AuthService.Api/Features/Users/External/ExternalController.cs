using System.Net;
using AuthService.Contracts.Users;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace AuthService.Api.Features.Users.External;

[ApiController]
[Route("api/users/external")]
public sealed class ExternalController : ControllerBase
{
    private readonly ISender _sender;
    public ExternalController(ISender sender) { _sender = sender; }

    [HttpPost("login")]
    [ProducesResponseType(typeof(TokenResponse), (int)HttpStatusCode.OK)]
    public Task<IResult> Login([FromBody] ExternalLoginRequest request, CancellationToken ct)
        => _sender.Send(new ExternalLoginCommand(request), ct);
}
