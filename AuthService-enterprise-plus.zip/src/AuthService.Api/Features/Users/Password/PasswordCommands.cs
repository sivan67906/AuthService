using AuthService.Contracts.Users;
using AuthService.Domain.Users;
using AuthService.Application.Abstractions;
using MediatR;
using Microsoft.AspNetCore.Identity;

namespace AuthService.Api.Features.Users.Password;

public sealed record ChangePasswordCommand(AppUser User, ChangePasswordRequest Request) : IRequest<IResult>;
public sealed record ForgotPasswordCommand(ForgotPasswordRequest Request) : IRequest<IResult>;
public sealed record ResetPasswordCommand(ResetPasswordRequest Request) : IRequest<IResult>;

public sealed class ChangePasswordHandler : IRequestHandler<ChangePasswordCommand, IResult>
{
    private readonly UserManager<AppUser> _userManager;
    public ChangePasswordHandler(UserManager<AppUser> userManager) { _userManager = userManager; }

    public async Task<IResult> Handle(ChangePasswordCommand cmd, CancellationToken ct)
    {
        var res = await _userManager.ChangePasswordAsync(cmd.User, cmd.Request.CurrentPassword, cmd.Request.NewPassword);
        return res.Succeeded ? Results.Ok() : Results.BadRequest(res.Errors.Select(e => e.Description));
    }
}

public sealed class ForgotPasswordHandler : IRequestHandler<ForgotPasswordCommand, IResult>
{
    private readonly UserManager<AppUser> _userManager;
    private readonly IEmailSender _email;
    public ForgotPasswordHandler(UserManager<AppUser> userManager, IEmailSender email) { _userManager = userManager; _email = email; }

    public async Task<IResult> Handle(ForgotPasswordCommand cmd, CancellationToken ct)
    {
        var user = await _userManager.FindByEmailAsync(cmd.Request.Email);
        if (user is null) return Results.Ok(); // do not reveal
        var token = await _userManager.GeneratePasswordResetTokenAsync(user);
        await _email.SendPasswordResetAsync(user.Email!, token, ct);
        return Results.Ok();
    }
}

public sealed class ResetPasswordHandler : IRequestHandler<ResetPasswordCommand, IResult>
{
    private readonly UserManager<AppUser> _userManager;
    public ResetPasswordHandler(UserManager<AppUser> userManager) { _userManager = userManager; }

    public async Task<IResult> Handle(ResetPasswordCommand cmd, CancellationToken ct)
    {
        var user = await _userManager.FindByEmailAsync(cmd.Request.Email);
        if (user is null) return Results.BadRequest();
        var res = await _userManager.ResetPasswordAsync(user, cmd.Request.Token, cmd.Request.NewPassword);
        return res.Succeeded ? Results.Ok() : Results.BadRequest(res.Errors.Select(e => e.Description));
    }
}
