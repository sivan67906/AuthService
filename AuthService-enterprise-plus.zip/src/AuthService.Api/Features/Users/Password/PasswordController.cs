using System.Net;
using System.Security.Claims;
using AuthService.Contracts.Users;
using AuthService.Domain.Users;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace AuthService.Api.Features.Users.Password;

[ApiController]
[Route("api/users/password")]
public sealed class PasswordController : ControllerBase
{
    private readonly ISender _sender;
    private readonly UserManager<AppUser> _userManager;
    public PasswordController(ISender sender, UserManager<AppUser> userManager) { _sender = sender; _userManager = userManager; }

    [Authorize]
    [HttpPost("change")]
    public async Task<IResult> Change([FromBody] ChangePasswordRequest req, CancellationToken ct)
    {
        var user = await _userManager.GetUserAsync(User);
        if (user is null) return Results.Unauthorized();
        return await _sender.Send(new ChangePasswordCommand(user, req), ct);
    }

    [HttpPost("forgot")]
    public Task<IResult> Forgot([FromBody] ForgotPasswordRequest req, CancellationToken ct)
        => _sender.Send(new ForgotPasswordCommand(req), ct);

    [HttpPost("reset")]
    public Task<IResult> Reset([FromBody] ResetPasswordRequest req, CancellationToken ct)
        => _sender.Send(new ResetPasswordCommand(req), ct);
}
