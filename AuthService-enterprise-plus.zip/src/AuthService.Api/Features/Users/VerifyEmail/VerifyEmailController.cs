using System.Net;
using AuthService.Domain.Users;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace AuthService.Api.Features.Users.VerifyEmail;

[ApiController]
[Route("api/users/verify-email")]
public sealed class VerifyEmailController : ControllerBase
{
    private readonly UserManager<AppUser> _userManager;
    public VerifyEmailController(UserManager<AppUser> userManager) { _userManager = userManager; }

    public sealed record VerifyEmailRequest(string Email, string Token);

    [HttpPost]
    [ProducesResponseType(typeof(void), (int)HttpStatusCode.OK)]
    public async Task<IActionResult> Verify([FromBody] VerifyEmailRequest req)
    {
        var user = await _userManager.FindByEmailAsync(req.Email);
        if (user is null) return NotFound();
        var result = await _userManager.ConfirmEmailAsync(user, req.Token);
        if (!result.Succeeded) return BadRequest(result.Errors.Select(e => e.Description));
        return Ok();
    }
}
