using System.Text.Json;
using AuthService.Application.Abstractions;
using AuthService.Contracts.Users;
using AuthService.Domain.Users;
using AuthService.Infrastructure.Commands;
using AuthService.Infrastructure.Commands.Outbox;
using FluentValidation;
using MapsterMapper;
using MediatR;
using Microsoft.AspNetCore.Identity;

namespace AuthService.Api.Features.Users.Register;

public sealed record RegisterUserCommand(RegisterRequest Request) : IRequest<IResult>;

public sealed class RegisterUserHandler : IRequestHandler<RegisterUserCommand, IResult>
{
    private readonly IValidator<RegisterRequest> _validator;
    private readonly UserManager<AppUser> _userManager;
    private readonly IMapper _mapper;
    private readonly CommandDbContext _cmdDb;
    private readonly IEmailSender _email;

    public RegisterUserHandler(IValidator<RegisterRequest> validator, UserManager<AppUser> userManager, IMapper mapper, CommandDbContext cmdDb, IEmailSender email)
    {
        _validator = validator; _userManager = userManager; _mapper = mapper; _cmdDb = cmdDb; _email = email;
    }

    public async Task<IResult> Handle(RegisterUserCommand command, CancellationToken ct)
    {
        var request = command.Request;
        var res = await _validator.ValidateAsync(request, ct);
        if (!res.IsValid) return Results.BadRequest(res.Errors.Select(e => e.ErrorMessage));

        var exists = await _userManager.FindByEmailAsync(request.Email);
        if (exists is not null) return Results.BadRequest(new [] { "Email already registered." });

        var user = new AppUser { UserName = request.Email, Email = request.Email, FirstName=request.FirstName, LastName=request.LastName };
        var created = await _userManager.CreateAsync(user, request.Password);
        if (!created.Succeeded) return Results.BadRequest(created.Errors.Select(e => e.Description));

        var token = await _userManager.GenerateEmailConfirmationTokenAsync(user);
        await _email.SendEmailConfirmationAsync(user.Email!, token, ct);

        var roles = await _userManager.GetRolesAsync(user);
        var payload = JsonSerializer.Serialize(new { Id = user.Id, user.Email, user.FirstName, user.LastName, Roles = roles.ToArray() });
        _cmdDb.Outbox.Add(new OutboxMessage { Type = "UserCreated", Payload = payload });
        await _cmdDb.SaveChangesAsync(ct);

        return Results.Ok(new { message = "Registered. Email confirmation sent. Use VerifyMail to confirm." });
    }
}
