
using System.Net;
using AuthService.Contracts.Users;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace AuthService.Api.Features.Users.Register;

[ApiController]
[Route("api/users/register")]
public sealed class RegisterController : ControllerBase
{
    private readonly ISender _sender;
    public RegisterController(ISender sender) { _sender = sender; }

    [HttpPost]
    [ProducesResponseType(typeof(void), (int)HttpStatusCode.OK)]
    public async Task<IResult> Register([FromBody] RegisterRequest request, CancellationToken ct)
        => await _sender.Send(new RegisterUserCommand(request), ct);
}
