using System.Security.Claims;
using AuthService.Contracts.Users;
using AuthService.Infrastructure.Queries;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace AuthService.Api.Features.Users.Profile;

public sealed record GetProfileQuery() : IRequest<IResult>;

public sealed class GetProfileHandler : IRequestHandler<GetProfileQuery, IResult>
{
    private readonly QueryDbContext _queryDb;
    private readonly IHttpContextAccessor _http;

    public GetProfileHandler(QueryDbContext queryDb, IHttpContextAccessor http)
    {
        _queryDb = queryDb; _http = http;
    }

    public async Task<IResult> Handle(GetProfileQuery request, CancellationToken cancellationToken)
    {
        var idStr = _http.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (string.IsNullOrEmpty(idStr)) return Results.Unauthorized();
        var id = Guid.Parse(idStr);
        var rm = await _queryDb.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
        if (rm is null) return Results.NotFound();
        var dto = new ProfileResponse(rm.Id, rm.Email, rm.FirstName, rm.LastName,
            rm.City is null ? null : new AddressDto("", null, rm.City, "", rm.Country ?? "", ""),
            rm.Roles);
        return Results.Ok(dto);
    }
}
