using System.Net;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AuthService.Api.Features.Users.Profile;

[ApiController]
[Route("api/users/profile")]
public sealed class ProfileController : ControllerBase
{
    private readonly ISender _sender;
    public ProfileController(ISender sender) { _sender = sender; }

    [Authorize]
    [HttpGet]
    [ProducesResponseType(typeof(void), (int)HttpStatusCode.OK)]
    public async Task<IResult> GetProfile(CancellationToken ct)
        => await _sender.Send(new GetProfileQuery(), ct);
    [Authorize]
    [HttpPut]
    public async Task<IResult> Update([FromBody] UpdateProfileRequest request, CancellationToken ct)
    {
        var user = HttpContext.RequestServices.GetRequiredService<UserManager<AuthService.Domain.Users.AppUser>>();
        var me = await user.GetUserAsync(User);
        if (me is null) return Results.Unauthorized();
        return await _sender.Send(new UpdateProfileCommand(me, request), ct);
    }
}
