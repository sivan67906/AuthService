using AuthService.Contracts.Users;
using AuthService.Domain.Users;
using AuthService.Infrastructure.Commands;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace AuthService.Api.Features.Users.Profile;

public sealed record UpdateProfileCommand(AppUser User, UpdateProfileRequest Request) : IRequest<IResult>;

public sealed class UpdateProfileHandler : IRequestHandler<UpdateProfileCommand, IResult>
{
    private readonly UserManager<AppUser> _userManager;
    private readonly CommandDbContext _db;
    public UpdateProfileHandler(UserManager<AppUser> userManager, CommandDbContext db) { _userManager = userManager; _db = db; }

    public async Task<IResult> Handle(UpdateProfileCommand cmd, CancellationToken ct)
    {
        var u = await _userManager.Users.Include(x => x.Address).FirstAsync(x => x.Id == cmd.User.Id, ct);
        u.FirstName = cmd.Request.FirstName ?? u.FirstName;
        u.LastName = cmd.Request.LastName ?? u.LastName;
        if (cmd.Request.Address is not null)
        {
            u.Address ??= new UserAddress();
            u.Address.Line1 = cmd.Request.Address.Line1;
            u.Address.Line2 = cmd.Request.Address.Line2;
            u.Address.City = cmd.Request.Address.City;
            u.Address.State = cmd.Request.Address.State;
            u.Address.Country = cmd.Request.Address.Country;
            u.Address.ZipCode = cmd.Request.Address.ZipCode;
        }
        await _db.SaveChangesAsync(ct);
        return Results.Ok();
    }
}
