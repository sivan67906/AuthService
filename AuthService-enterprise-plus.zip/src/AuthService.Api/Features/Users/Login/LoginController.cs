
using System.Net;
using AuthService.Contracts.Users;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace AuthService.Api.Features.Users.Login;

[ApiController]
[Route("api/users/login")]
public sealed class LoginController : ControllerBase
{
    private readonly ISender _sender;
    public LoginController(ISender sender) { _sender = sender; }

    [HttpPost]
    [ProducesResponseType(typeof(TokenResponse), (int)HttpStatusCode.OK)]
    public async Task<IResult> Login([FromBody] LoginRequest request, CancellationToken ct)
        => await _sender.Send(new LoginCommand(request), ct);
}
