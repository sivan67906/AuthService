using AuthService.Application.Abstractions;
using AuthService.Contracts.Users;
using AuthService.Domain.Users;
using MediatR;
using Microsoft.AspNetCore.Identity;

namespace AuthService.Api.Features.Users.Login;

public sealed record LoginCommand(LoginRequest Request) : IRequest<IResult>;

public sealed class LoginHandler : IRequestHandler<LoginCommand, IResult>
{
    private readonly ITokenService _tokenService;
    private readonly SignInManager<AppUser> _signInManager;
    private readonly UserManager<AppUser> _userManager;

    public LoginHandler(ITokenService tokenService, SignInManager<AppUser> signInManager, UserManager<AppUser> userManager)
    {
        _tokenService = tokenService; _signInManager = signInManager; _userManager = userManager;
    }

    public async Task<IResult> Handle(LoginCommand command, CancellationToken ct)
    {
        var request = command.Request;
        var user = await _userManager.FindByEmailAsync(request.Email);
        if (user is null) return Results.Unauthorized();

        if (!await _userManager.IsEmailConfirmedAsync(user))
            return Results.Unauthorized();

        if (await _userManager.GetTwoFactorEnabledAsync(user))
        {
            if (!string.IsNullOrWhiteSpace(request.TwoFactorCode))
            {
                var valid2fa = await _signInManager.TwoFactorAuthenticatorSignInAsync(request.TwoFactorCode, true, false);
                if (!valid2fa.Succeeded) return Results.Unauthorized();
            }
            else if (!string.IsNullOrWhiteSpace(request.TwoFactorRecoveryCode))
            {
                var resRec = await _signInManager.TwoFactorRecoveryCodeSignInAsync(request.TwoFactorRecoveryCode);
                if (!resRec.Succeeded) return Results.Unauthorized();
            }
            else
            {
                return Results.Unauthorized();
            }
        }
        else
        {
            var passwordOk = await _signInManager.CheckPasswordSignInAsync(user, request.Password, false);
            if (!passwordOk.Succeeded) return Results.Unauthorized();
        }

        var roles = await _userManager.GetRolesAsync(user);
        var (accessToken, expires) = _tokenService.CreateAccessToken(user, roles);
        var refreshToken = await _tokenService.CreateAndStoreRefreshTokenAsync(user);

        return Results.Ok(new TokenResponse(accessToken, refreshToken, expires));
    }
}
