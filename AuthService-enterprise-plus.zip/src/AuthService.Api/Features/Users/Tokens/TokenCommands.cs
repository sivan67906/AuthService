using System.Security.Claims;
using AuthService.Application.Abstractions;
using AuthService.Contracts.Users;
using AuthService.Domain.Users;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;

namespace AuthService.Api.Features.Users.Tokens;

public sealed record RefreshTokenCommand(RefreshTokenRequest Request) : IRequest<IResult>;
public sealed record RevokeTokenCommand(RefreshTokenRequest Request) : IRequest<IResult>;

public sealed class RefreshTokenHandler : IRequestHandler<RefreshTokenCommand, IResult>
{
    private readonly ITokenService _tokenService;
    private readonly IHttpContextAccessor _http;
    private readonly UserManager<AppUser> _userManager;
    public RefreshTokenHandler(ITokenService tokenService, IHttpContextAccessor http, UserManager<AppUser> userManager)
    { _tokenService = tokenService; _http = http; _userManager = userManager; }

    public async Task<IResult> Handle(RefreshTokenCommand command, CancellationToken cancellationToken)
    {
        var userId = _http.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (string.IsNullOrEmpty(userId)) return Results.Unauthorized();
        var user = await _userManager.FindByIdAsync(userId);
        if (user is null) return Results.Unauthorized();

        var valid = await _tokenService.ValidateRefreshTokenAsync(user.Id, command.Request.RefreshToken, cancellationToken);
        if (!valid) return Results.Unauthorized();

        var roles = await _userManager.GetRolesAsync(user);
        var (accessToken, expires) = _tokenService.CreateAccessToken(user, roles);
        return Results.Ok(new TokenResponse(accessToken, command.Request.RefreshToken, expires));
    }
}

public sealed class RevokeTokenHandler : IRequestHandler<RevokeTokenCommand, IResult>
{
    private readonly ITokenService _tokenService;
    public RevokeTokenHandler(ITokenService tokenService) { _tokenService = tokenService; }

    public async Task<IResult> Handle(RevokeTokenCommand command, CancellationToken cancellationToken)
    {
        var ok = await _tokenService.RevokeRefreshTokenAsync(command.Request.RefreshToken, cancellationToken);
        return ok ? Results.Ok() : Results.NotFound();
    }
}
