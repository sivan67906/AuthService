using System.Net;
using AuthService.Contracts.Users;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AuthService.Api.Features.Users.Tokens;

[ApiController]
[Route("api/users/token")]
public sealed class TokenController : ControllerBase
{
    private readonly ISender _sender;
    public TokenController(ISender sender) { _sender = sender; }

    [HttpPost("refresh")]
    [ProducesResponseType(typeof(TokenResponse), (int)HttpStatusCode.OK)]
    public Task<IResult> Refresh([FromBody] RefreshTokenRequest req, CancellationToken ct)
        => _sender.Send(new RefreshTokenCommand(req), ct);

    [Authorize]
    [HttpPost("revoke")]
    public Task<IResult> Revoke([FromBody] RefreshTokenRequest req, CancellationToken ct)
        => _sender.Send(new RevokeTokenCommand(req), ct);
}
