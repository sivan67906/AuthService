using AuthService.Contracts.Users;
using AuthService.Domain.Users;
using AuthService.Infrastructure.Commands;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace AuthService.Api.Features.Users.Address;

public sealed record UpsertAddressCommand(AppUser User, AddressDto Address) : IRequest<IResult>;
public sealed record GetAddressQuery(AppUser User) : IRequest<IResult>;

public sealed class UpsertAddressHandler : IRequestHandler<UpsertAddressCommand, IResult>
{
    private readonly CommandDbContext _db;
    private readonly UserManager<AppUser> _userManager;
    public UpsertAddressHandler(CommandDbContext db, UserManager<AppUser> userManager) { _db = db; _userManager = userManager; }

    public async Task<IResult> Handle(UpsertAddressCommand cmd, CancellationToken ct)
    {
        var user = await _userManager.Users.Include(u => u.Address).FirstAsync(u => u.Id == cmd.User.Id, ct);
        if (user.Address is null) user.Address = new UserAddress();
        user.Address.Line1 = cmd.Address.Line1;
        user.Address.Line2 = cmd.Address.Line2;
        user.Address.City = cmd.Address.City;
        user.Address.State = cmd.Address.State;
        user.Address.Country = cmd.Address.Country;
        user.Address.ZipCode = cmd.Address.ZipCode;
        await _db.SaveChangesAsync(ct);
        return Results.Ok();
    }
}

public sealed class GetAddressHandler : IRequestHandler<GetAddressQuery, IResult>
{
    private readonly UserManager<AppUser> _userManager;
    public GetAddressHandler(UserManager<AppUser> userManager) { _userManager = userManager; }

    public async Task<IResult> Handle(GetAddressQuery cmd, CancellationToken ct)
    {
        var user = await _userManager.Users.Include(u => u.Address).FirstOrDefaultAsync(u => u.Id == cmd.User.Id, ct);
        if (user?.Address is null) return Results.NotFound();
        var a = user.Address;
        return Results.Ok(new AddressDto(a.Line1, a.Line2, a.City, a.State, a.Country, a.ZipCode));
    }
}
