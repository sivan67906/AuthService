using System.Net;
using AuthService.Contracts.Users;
using AuthService.Domain.Users;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace AuthService.Api.Features.Users.Address;

[ApiController]
[Route("api/users/address")]
public sealed class AddressController : ControllerBase
{
    private readonly ISender _sender;
    private readonly UserManager<AppUser> _userManager;
    public AddressController(ISender sender, UserManager<AppUser> userManager) { _sender = sender; _userManager = userManager; }

    [Authorize]
    [HttpPut]
    public async Task<IResult> Upsert([FromBody] AddressDto dto, CancellationToken ct)
    {
        var user = await _userManager.GetUserAsync(User);
        if (user is null) return Results.Unauthorized();
        return await _sender.Send(new UpsertAddressCommand(user, dto), ct);
    }

    [Authorize]
    [HttpGet]
    public async Task<IResult> Get(CancellationToken ct)
    {
        var user = await _userManager.GetUserAsync(User);
        if (user is null) return Results.Unauthorized();
        return await _sender.Send(new GetAddressQuery(user), ct);
    }
}
