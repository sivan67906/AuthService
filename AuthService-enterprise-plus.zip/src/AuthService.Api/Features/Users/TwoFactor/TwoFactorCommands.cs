using AuthService.Domain.Users;
using MediatR;
using Microsoft.AspNetCore.Identity;

namespace AuthService.Api.Features.Users.TwoFactor;

public sealed record Enable2FACommand(AppUser User) : IRequest<IResult>;
public sealed record Disable2FACommand(AppUser User) : IRequest<IResult>;

public sealed class Enable2FAHandler : IRequestHandler<Enable2FACommand, IResult>
{
    private readonly UserManager<AppUser> _userManager;
    public Enable2FAHandler(UserManager<AppUser> userManager) { _userManager = userManager; }

    public async Task<IResult> Handle(Enable2FACommand request, CancellationToken cancellationToken)
    {
        var key = await _userManager.GetAuthenticatorKeyAsync(request.User);
        if (string.IsNullOrEmpty(key))
        {
            await _userManager.ResetAuthenticatorKeyAsync(request.User);
            key = await _userManager.GetAuthenticatorKeyAsync(request.User);
        }
        await _userManager.SetTwoFactorEnabledAsync(request.User, true);
        var recovery = await _userManager.GenerateNewTwoFactorRecoveryCodesAsync(request.User, 10);
        return Results.Ok(new { sharedKey = key, recoveryCodes = recovery });
    }
}

public sealed class Disable2FAHandler : IRequestHandler<Disable2FACommand, IResult>
{
    private readonly UserManager<AppUser> _userManager;
    public Disable2FAHandler(UserManager<AppUser> userManager) { _userManager = userManager; }

    public async Task<IResult> Handle(Disable2FACommand request, CancellationToken cancellationToken)
    {
        await _userManager.SetTwoFactorEnabledAsync(request.User, false);
        return Results.Ok();
    }
}
