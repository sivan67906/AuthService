using System.Net;
using AuthService.Domain.Users;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace AuthService.Api.Features.Users.TwoFactor;

[ApiController]
[Route("api/users/2fa")]
public sealed class TwoFactorController : ControllerBase
{
    private readonly ISender _sender;
    private readonly UserManager<AppUser> _userManager;
    public TwoFactorController(ISender sender, UserManager<AppUser> userManager) { _sender = sender; _userManager = userManager; }

    [Authorize]
    [HttpPost("enable")]
    public async Task<IResult> Enable(CancellationToken ct)
    {
        var user = await _userManager.GetUserAsync(User);
        if (user is null) return Results.Unauthorized();
        return await _sender.Send(new Enable2FACommand(user), ct);
    }

    [Authorize]
    [HttpPost("disable")]
    public async Task<IResult> Disable(CancellationToken ct)
    {
        var user = await _userManager.GetUserAsync(User);
        if (user is null) return Results.Unauthorized();
        return await _sender.Send(new Disable2FACommand(user), ct);
    }
}
