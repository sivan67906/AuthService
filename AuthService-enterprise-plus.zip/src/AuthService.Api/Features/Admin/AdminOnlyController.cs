using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AuthService.Api.Features.Admin;

[ApiController]
[Route("api/admin")]
[Authorize(Roles="Admin")]
public sealed class AdminOnlyController : ControllerBase
{
    [HttpGet("secure-data")]
    public IActionResult Get() => Ok(new { secret = "Only admins can see this." });
}
