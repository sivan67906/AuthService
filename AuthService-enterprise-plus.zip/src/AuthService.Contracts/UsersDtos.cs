namespace AuthService.Contracts.Users;

public sealed record RegisterRequest(string Email, string Password, string? FirstName, string? LastName);
public sealed record LoginRequest(string Email, string Password, string? TwoFactorCode, string? TwoFactorRecoveryCode);
public sealed record RefreshTokenRequest(string RefreshToken);
public sealed record ForgotPasswordRequest(string Email);
public sealed record ResetPasswordRequest(string Email, string Token, string NewPassword);
public sealed record ChangePasswordRequest(string CurrentPassword, string NewPassword);
public sealed record AddressDto(string Line1, string? Line2, string City, string State, string Country, string ZipCode);
public sealed record UpdateProfileRequest(string? FirstName, string? LastName, AddressDto? Address);
public sealed record ExternalLoginRequest(string Provider, string IdToken);
public sealed record TokenResponse(string AccessToken, string RefreshToken, DateTime ExpiresAtUtc);
public sealed record ProfileResponse(Guid Id, string Email, string? FirstName, string? LastName, AddressDto? Address, string[] Roles);
