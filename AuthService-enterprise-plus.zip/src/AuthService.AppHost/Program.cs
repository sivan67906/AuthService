using Aspire.Hosting;

var builder = DistributedApplication.CreateBuilder(args);

var sql = builder.AddSqlServer("sql")
    .WithPassword("Your_password123")
    .AddDatabase("AuthService");

var pg = builder.AddPostgres("pg")
    .WithDataVolume()
    .AddDatabase("auth_read");

var api = builder.AddProject<Projects.AuthService_Api>("authservice-api")
    .WithReference(sql)
    .WithReference(pg);

builder.Build().Run();
