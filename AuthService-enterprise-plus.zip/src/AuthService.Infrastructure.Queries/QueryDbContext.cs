using Microsoft.EntityFrameworkCore;

namespace AuthService.Infrastructure.Queries;

public sealed class QueryDbContext : DbContext
{
    public QueryDbContext(DbContextOptions<QueryDbContext> options) : base(options) {}
    public DbSet<UserReadModel> Users => Set<UserReadModel>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<UserReadModel>(b =>
        {
            b.HasKey(x => x.Id);
            b.Property(x => x.Email).IsRequired();
        });
    }
}

public sealed class UserReadModel
{
    public Guid Id { get; set; }
    public string Email { get; set; } = default!;
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string[] Roles { get; set; } = Array.Empty<string>();
    public string? City { get; set; }
    public string? Country { get; set; }
}
