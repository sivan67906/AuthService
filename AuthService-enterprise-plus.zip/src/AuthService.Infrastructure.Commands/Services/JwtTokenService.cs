using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using AuthService.Application.Abstractions;
using AuthService.Domain.Users;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Microsoft.EntityFrameworkCore;

namespace AuthService.Infrastructure.Commands.Services;

public sealed class JwtTokenService : ITokenService
{
    private readonly IConfiguration _cfg;
    private readonly CommandDbContext _db;
    public JwtTokenService(IConfiguration cfg, CommandDbContext db) { _cfg = cfg; _db = db; }

    public (string accessToken, DateTime expires) CreateAccessToken(AppUser user, IEnumerable<string> roles)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_cfg["Jwt:Key"]!));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var expires = DateTime.UtcNow.AddMinutes(int.Parse(_cfg["Jwt:ExpiresMinutes"] ?? "30"));

        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new(JwtRegisteredClaimNames.Email, user.Email!),
            new(ClaimTypes.NameIdentifier, user.Id.ToString())
        };
        claims.AddRange(roles.Select(r => new Claim(ClaimTypes.Role, r)));

        var token = new JwtSecurityToken(
            issuer: _cfg["Jwt:Issuer"],
            audience: _cfg["Jwt:Audience"],
            claims: claims,
            expires: expires,
            signingCredentials: creds);

        var jwt = new JwtSecurityTokenHandler().WriteToken(token);
        return (jwt, expires);
    }

    public async Task<string> CreateAndStoreRefreshTokenAsync(AppUser user, TimeSpan? lifetime = null, CancellationToken ct = default)
    {
        var token = Convert.ToBase64String(Guid.NewGuid().ToByteArray()) + Convert.ToBase64String(Guid.NewGuid().ToByteArray());
        var expires = DateTime.UtcNow.Add(lifetime ?? TimeSpan.FromDays(7));
        _db.RefreshTokens.Add(new RefreshToken { Id = Guid.NewGuid(), UserId = user.Id, Token = token, ExpiresUtc = expires, Revoked = false });
        await _db.SaveChangesAsync(ct);
        return token;
    }

    public async Task<bool> RevokeRefreshTokenAsync(string token, CancellationToken ct = default)
    {
        var rt = await _db.RefreshTokens.FirstOrDefaultAsync(x => x.Token == token, ct);
        if (rt is null) return false;
        rt.Revoked = true;
        await _db.SaveChangesAsync(ct);
        return true;
    }

    public async Task<bool> ValidateRefreshTokenAsync(Guid userId, string token, CancellationToken ct = default)
    {
        var rt = await _db.RefreshTokens.FirstOrDefaultAsync(x => x.UserId == userId && x.Token == token && !x.Revoked, ct);
        return rt is not null && rt.ExpiresUtc > DateTime.UtcNow;
    }
}
