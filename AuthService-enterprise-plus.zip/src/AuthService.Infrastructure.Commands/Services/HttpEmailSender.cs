using System.Net.Http;
using System.Text;
using System.Text.Json;
using AuthService.Application.Abstractions;
using Microsoft.Extensions.Configuration;

namespace AuthService.Infrastructure.Commands.Services;

public sealed class HttpEmailSender : IEmailSender
{
    private readonly IHttpClientFactory _factory;
    private readonly IConfiguration _cfg;
    public HttpEmailSender(IHttpClientFactory factory, IConfiguration cfg)
    {
        _factory = factory; _cfg = cfg;
    }

    private async Task PostAsync(object payload, CancellationToken ct)
    {
        var client = _factory.CreateClient("email");
        var url = _cfg["Email:Endpoint"] ?? "https://example-email.local/send";
        var json = JsonSerializer.Serialize(payload);
        var resp = await client.PostAsync(url, new StringContent(json, Encoding.UTF8, "application/json"), ct);
        // For demo, ignore non-success; in production, handle retries etc.
    }

    public Task SendEmailConfirmationAsync(string toEmail, string token, CancellationToken ct = default)
        => PostAsync(new { to = toEmail, subject = "Confirm your email", token }, ct);

    public Task SendPasswordResetAsync(string toEmail, string token, CancellationToken ct = default)
        => PostAsync(new { to = toEmail, subject = "Reset your password", token }, ct);
}
