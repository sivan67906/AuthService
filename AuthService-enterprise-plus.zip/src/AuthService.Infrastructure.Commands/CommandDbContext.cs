using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using AuthService.Domain.Users;
using AuthService.Infrastructure.Commands.Outbox;

namespace AuthService.Infrastructure.Commands;

public sealed class CommandDbContext : IdentityDbContext<AppUser, AppRole, Guid>
{
    public CommandDbContext(DbContextOptions<CommandDbContext> options) : base(options) {}
    public DbSet<UserAddress> Addresses => Set<UserAddress>();
    public DbSet<RefreshToken> RefreshTokens => Set<RefreshToken>();
    public DbSet<OutboxMessage> Outbox => Set<OutboxMessage>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<AppUser>(b =>
        {
            b.HasOne(u => u.Address)
             .WithOne(a => a.User)
             .HasForeignKey<UserAddress>(a => a.UserId);
        });

        builder.Entity<UserAddress>(b =>
        {
            b.Property(x => x.Line1).IsRequired().HasMaxLength(200);
            b.Property(x => x.City).IsRequired().HasMaxLength(100);
            b.Property(x => x.State).IsRequired().HasMaxLength(100);
            b.Property(x => x.Country).IsRequired().HasMaxLength(100);
            b.Property(x => x.ZipCode).IsRequired().HasMaxLength(20);
        });

        builder.Entity<RefreshToken>(b =>
        {
            b.HasIndex(x => x.Token).IsUnique();
            b.Property(x => x.Token).IsRequired().HasMaxLength(200);
        });

        builder.Entity<OutboxMessage>(b =>
        {
            b.Property(x => x.Type).IsRequired().HasMaxLength(200);
            b.Property(x => x.Payload).IsRequired();
            b.HasIndex(x => x.ProcessedUtc);
        });
    }
}
