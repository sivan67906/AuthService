using AuthService.Domain.Users;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace AuthService.Infrastructure.Commands.Seed;

public static class CommandDbSeeder
{
    public static async Task SeedAsync(IServiceProvider sp, ILogger logger)
    {
        using var scope = sp.CreateScope();
        var roleMgr = scope.ServiceProvider.GetRequiredService<RoleManager<AppRole>>();
        var userMgr = scope.ServiceProvider.GetRequiredService<UserManager<AppUser>>();
        var db = scope.ServiceProvider.GetRequiredService<CommandDbContext>();
        await db.Database.MigrateAsync();

        foreach (var role in new[] {"Admin","Manager","User"})
        {
            if (!await roleMgr.RoleExistsAsync(role))
                await roleMgr.CreateAsync(new AppRole(role));
        }

        var adminEmail = "admin@example.com";
        var admin = await userMgr.FindByEmailAsync(adminEmail);
        if (admin is null)
        {
            admin = new AppUser { UserName = adminEmail, Email = adminEmail, EmailConfirmed = true, FirstName = "System", LastName = "Admin" };
            var res = await userMgr.CreateAsync(admin, "Admin@12345");
            if (res.Succeeded)
                await userMgr.AddToRolesAsync(admin, new[] { "Admin" });
        }
    }
}
