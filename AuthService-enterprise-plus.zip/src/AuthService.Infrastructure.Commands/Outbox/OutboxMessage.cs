namespace AuthService.Infrastructure.Commands.Outbox;

public sealed class OutboxMessage
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Type { get; set; } = default!; // e.g., "UserCreated"
    public string Payload { get; set; } = default!; // JSON
    public DateTime CreatedUtc { get; init; } = DateTime.UtcNow;
    public DateTime? ProcessedUtc { get; set; }
    public string? Error { get; set; }
}
