namespace AuthService.Domain.Common;

public sealed class Result
{
    public bool IsSuccess { get; }
    public string? Error { get; }
    public static Result Success() => new(true, null);
    public static Result Failure(string error) => new(false, error);
    private Result(bool ok, string? error) { IsSuccess = ok; Error = error; }
}

public sealed class Result<T>
{
    public bool IsSuccess { get; }
    public string? Error { get; }
    public T? Value { get; }
    public static Result<T> Success(T value) => new(true, value, null);
    public static Result<T> Failure(string error) => new(false, default, error);
    private Result<T>(bool ok, T? value, string? error) { IsSuccess = ok; Value = value; Error = error; }
}
