using Microsoft.AspNetCore.Identity;

namespace AuthService.Domain.Users;

public sealed class AppUser : IdentityUser<Guid>
{
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public UserAddress? Address { get; set; }
    public bool IsDeleted { get; set; } = false;
    public DateTime CreatedUtc { get; init; } = DateTime.UtcNow;
}

public sealed class AppRole : IdentityRole<Guid>
{
    public AppRole() : base() {}
    public AppRole(string name) : base(name) {}
}

public sealed class UserAddress
{
    public Guid Id { get; set; }
    public string Line1 { get; set; } = default!;
    public string? Line2 { get; set; }
    public string City { get; set; } = default!;
    public string State { get; set; } = default!;
    public string Country { get; set; } = default!;
    public string ZipCode { get; set; } = default!;
    public Guid UserId { get; set; }
    public AppUser User { get; set; } = default!;
}
