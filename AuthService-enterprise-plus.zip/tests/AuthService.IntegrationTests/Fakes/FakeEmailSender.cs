using System.Collections.Concurrent;
using AuthService.Application.Abstractions;

namespace AuthService.IntegrationTests.Fakes;

public sealed class FakeEmailSender : IEmailSender
{
    private readonly ConcurrentDictionary<string,string> _confirm = new();
    private readonly ConcurrentDictionary<string,string> _reset = new();

    public Task SendEmailConfirmationAsync(string toEmail, string token, CancellationToken ct = default)
    {
        _confirm[toEmail] = token;
        return Task.CompletedTask;
    }

    public Task SendPasswordResetAsync(string toEmail, string token, CancellationToken ct = default)
    {
        _reset[toEmail] = token;
        return Task.CompletedTask;
    }

    public bool TryGetConfirmation(string email, out string token) => _confirm.TryGetValue(email, out token!);
    public bool TryGetReset(string email, out string token) => _reset.TryGetValue(email, out token!);
}
