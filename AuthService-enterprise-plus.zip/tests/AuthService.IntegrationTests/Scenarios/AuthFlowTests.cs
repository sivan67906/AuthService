using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using AuthService.Contracts.Users;
using AuthService.IntegrationTests.Fakes;
using AuthService.IntegrationTests.Infra;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;

namespace AuthService.IntegrationTests.Scenarios;

public class AuthFlowTests : IClassFixture<CustomWebAppFactory>
{
    private readonly CustomWebAppFactory _factory;
    private readonly HttpClient _client;
    public AuthFlowTests(CustomWebAppFactory factory)
    {
        _factory = factory;
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task Register_Verify_Login_Profile_Address_EndToEnd()
    {
        var email = $"user{Guid.NewGuid():N}@example.com";
        var pwd = "Test@12345";

        // Register
        var reg = new RegisterRequest(email, pwd, "First", "Last");
        var regResp = await _client.PostAsJsonAsync("/api/users/register", reg);
        regResp.EnsureSuccessStatusCode();

        // Get confirmation token from fake email sender
        var fake = _factory.Services.GetRequiredService<FakeEmailSender>();
        fake.TryGetConfirmation(email, out var token).Should().BeTrue();

        // Verify
        var verifyResp = await _client.PostAsJsonAsync("/api/users/verify-email", new { Email = email, Token = token });
        verifyResp.EnsureSuccessStatusCode();

        // Login
        var loginResp = await _client.PostAsJsonAsync("/api/users/login", new LoginRequest(email, pwd, null, null));
        loginResp.EnsureSuccessStatusCode();
        var tokens = await loginResp.Content.ReadFromJsonAsync<TokenResponse>();
        tokens.Should().NotBeNull();
        var access = tokens!.AccessToken;
        var refresh = tokens.RefreshToken;

        // Profile GET
        var req = new HttpRequestMessage(HttpMethod.Get, "/api/users/profile");
        req.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", access);
        var profileResp = await _client.SendAsync(req);
        profileResp.EnsureSuccessStatusCode();
        var profile = await profileResp.Content.ReadFromJsonAsync<ProfileResponse>();
        profile!.Email.Should().Be(email);

        // Address Upsert + Get
        var addr = new AddressDto("L1", null, "City", "State", "Country", "00000");
        var put = new HttpRequestMessage(HttpMethod.Put, "/api/users/address") { Content = JsonContent.Create(addr) };
        put.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", access);
        var putResp = await _client.SendAsync(put);
        putResp.EnsureSuccessStatusCode();

        var get = new HttpRequestMessage(HttpMethod.Get, "/api/users/address");
        get.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", access);
        var getResp = await _client.SendAsync(get);
        getResp.EnsureSuccessStatusCode();

        // Refresh token
        var refreshReq = new HttpRequestMessage(HttpMethod.Post, "/api/users/token/refresh") { Content = JsonContent.Create(new RefreshTokenRequest(refresh)) };
        refreshReq.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", access);
        var refreshResp = await _client.SendAsync(refreshReq);
        refreshResp.EnsureSuccessStatusCode();
    }
}
