using System.Net.Http;
using AuthService.Application.Abstractions;
using AuthService.Infrastructure.Commands;
using AuthService.Infrastructure.Queries;
using AuthService.IntegrationTests.Fakes;
using DotNet.Testcontainers.Builders;
using DotNet.Testcontainers.Containers;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace AuthService.IntegrationTests.Infra;

public sealed class CustomWebAppFactory : WebApplicationFactory<Program>, IAsyncLifetime
{
    private MsSqlContainer? _sql;
    private PostgreSqlContainer? _pg;

    public string SqlConnectionString => _sql!.GetConnectionString();
    public string PgConnectionString => _pg!.GetConnectionString();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Development");
        builder.ConfigureServices(services =>
        {
            // Replace Email sender with fake
            services.AddSingleton<IEmailSender, FakeEmailSender>();

            // Replace DbContexts with container connection strings
            var sp = services.BuildServiceProvider();
            using var scope = sp.CreateScope();

            // Remove existing DB context registrations and re-add with container connection strings
            var cmdDesc = services.Single(d => d.ServiceType == typeof(DbContextOptions<CommandDbContext>));
            services.Remove(cmdDesc);
            services.AddDbContext<CommandDbContext>(o => o.UseSqlServer(SqlConnectionString));

            var qryDesc = services.Single(d => d.ServiceType == typeof(DbContextOptions<QueryDbContext>));
            services.Remove(qryDesc);
            services.AddDbContext<QueryDbContext>(o => o.UseNpgsql(PgConnectionString));
        });
    }

    public async Task InitializeAsync()
    {
        _sql = new MsSqlBuilder()
            .WithPassword("Your_password123")
            .Build();
        _pg = new PostgreSqlBuilder()
            .WithDatabase("auth_read")
            .WithUsername("postgres")
            .WithPassword("postgres")
            .Build();

        await _sql.StartAsync();
        await _pg.StartAsync();

        // Warm-up: ensure databases exist by starting and stopping a scope
        using var client = CreateClient();
        // Trigger app startup and DB seeding
        _ = await client.GetAsync("/health");
    }

    public new async Task DisposeAsync()
    {
        if (_sql is not null) await _sql.StopAsync();
        if (_pg is not null) await _pg.StopAsync();
    }
}
