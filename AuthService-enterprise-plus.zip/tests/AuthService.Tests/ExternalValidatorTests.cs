using AuthService.Api.Services;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using FluentAssertions;

namespace AuthService.Tests;

public class ExternalValidatorTests
{
    [Fact]
    public async Task Validator_Rejects_Invalid_Token()
    {
        var cfg = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string,string?>
        {
            ["ExternalAuth:Google:ClientId"] = "test-google-client-id.apps.googleusercontent.com",
            ["ExternalAuth:Microsoft:ClientId"] = "test-ms-client-id"
        }).Build();

        var validator = new ExternalIdTokenValidator(cfg, new MemoryCache(new MemoryCacheOptions()));
        var (ok, principal, error) = await validator.ValidateAsync("google", "not-a-jwt", default);
        ok.Should().BeFalse();
        principal.Should().BeNull();
        error.Should().NotBeNull();
    }
}
