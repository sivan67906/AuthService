using AuthService.Application.Users;
using AuthService.Contracts.Users;
using FluentAssertions;

namespace AuthService.Tests;

public class ValidationTests
{
    [Fact]
    public void Register_Validator_Blocks_Bad_Email()
    {
        var v = new RegisterRequestValidator();
        var r = v.Validate(new RegisterRequest("bad", "12345678", null, null));
        r.IsValid.Should().BeFalse();
    }

    [Fact]
    public void Register_Validator_Allows_Good_Data()
    {
        var v = new RegisterRequestValidator();
        var r = v.Validate(new RegisterRequest("a@b.com", "12345678", "A", "B"));
        r.IsValid.Should().BeTrue();
    }
}
