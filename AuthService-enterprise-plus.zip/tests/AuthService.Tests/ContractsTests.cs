using AuthService.Contracts.Users;
using FluentAssertions;

namespace AuthService.Tests;

public class ContractsTests
{
    [Fact]
    public void AddressDto_Allows_Nulls_For_Line2()
    {
        var dto = new AddressDto("L1", null, "City", "State", "Country", "00000");
        dto.Line2.Should().BeNull();
    }
}
