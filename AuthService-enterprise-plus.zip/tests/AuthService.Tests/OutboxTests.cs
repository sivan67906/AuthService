using System.Text.Json;
using AuthService.Infrastructure.Commands.Outbox;
using FluentAssertions;

namespace AuthService.Tests;

public class OutboxTests
{
    [Fact]
    public void OutboxMessage_Can_Serialize_UserCreated()
    {
        var payload = JsonSerializer.Serialize(new { Id = Guid.NewGuid(), Email = "a@b.com", FirstName = "A", LastName = "B", Roles = new [] { "User" } });
        var msg = new OutboxMessage { Type = "UserCreated", Payload = payload };
        msg.Id.Should().NotBeEmpty();
        msg.CreatedUtc.Should().BeBefore(DateTime.UtcNow.AddSeconds(1));
        msg.ProcessedUtc.Should().BeNull();
    }
}
